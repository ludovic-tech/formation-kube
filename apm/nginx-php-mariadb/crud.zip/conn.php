<?php
        $conn = mysqli_connect("localhost","crud_user","q1w2e3","crud");

// Check connection
        if (mysqli_connect_errno()){
                        echo "Failed to connect DB : " . mysqli_connect_error();
                }

?>
